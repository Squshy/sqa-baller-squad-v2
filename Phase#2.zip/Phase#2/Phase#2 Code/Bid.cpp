/**
* Bid Function Definition file for Our Auction Sales Service Project 
*
* @author Paul Kerrigan, Henry Zheng, Calvin Lapp
* @date January 24, 2020
* @version  1.0
* @name Bid.cpp
*/

#include "Bid.h"
#include <string>

Bid::Bid(){

}

float Bid::CalculateLowestBid(){

}

void Bid::BidOnItem(){
    
}