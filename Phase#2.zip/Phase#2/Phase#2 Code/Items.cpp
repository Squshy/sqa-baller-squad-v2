/**
* Items Function Definition file for Our Auction Sales Service Project 
*
* @author Paul Kerrigan, Henry Zheng, Calvin Lapp
* @date January 24, 2020
* @version  1.0
* @name Items.cpp
*/

#include "Items.h"
#include <string>

Items::Items(){
    
}

void Items::CheckItems(){

}

void Items::FindItems(){
    
}