var searchData=
[
  ['readusersfile_82',['ReadUsersFile',['../class_users.html#adab738688dd3ae10fa62887bc62fdf13',1,'Users']]],
  ['refund_83',['Refund',['../class_admin.html#a904ec0e5ab61b056f11c8e9dfa8be60c',1,'Admin']]]
];
