var searchData=
[
  ['available_5fitems_5ffile_100',['AVAILABLE_ITEMS_FILE',['../class_writer.html#a77cf1d14243ea258128b47c8ab4d1b84',1,'Writer']]]
];
