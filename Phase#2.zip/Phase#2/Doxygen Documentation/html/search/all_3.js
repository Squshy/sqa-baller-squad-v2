var searchData=
[
  ['daily_5ftransaction_5ffile_12',['DAILY_TRANSACTION_FILE',['../class_writer.html#a3222bafbd1fab99f4548e7c049ed6775',1,'Writer']]],
  ['deleteuser_13',['DeleteUser',['../class_admin.html#a027a095434a0373d22f4d45728511b19',1,'Admin']]],
  ['disableuser_14',['DisableUser',['../class_admin.html#a6f8d87913fd1c9954029ca7a67517b0d',1,'Admin']]]
];
