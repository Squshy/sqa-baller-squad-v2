var searchData=
[
  ['daily_5ftransaction_5ffile_102',['DAILY_TRANSACTION_FILE',['../class_writer.html#a3222bafbd1fab99f4548e7c049ed6775',1,'Writer']]]
];
