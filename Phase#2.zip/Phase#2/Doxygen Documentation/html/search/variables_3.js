var searchData=
[
  ['minimum_5fbid_5fpercent_103',['MINIMUM_BID_PERCENT',['../class_bid.html#ae61d538ec591d024167690a2867601ab',1,'Bid']]]
];
