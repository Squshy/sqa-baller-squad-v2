var searchData=
[
  ['validatecredentials_45',['ValidateCredentials',['../class_users.html#a67c39b95759f19d1aa3cfd9c054986a2',1,'Users']]]
];
