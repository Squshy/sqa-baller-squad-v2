var searchData=
[
  ['getbidprice_70',['getBidPrice',['../class_items.html#a2a53895088a607a55109cfa6a1784ec0',1,'Items']]],
  ['getcredits_71',['getCredits',['../class_users.html#aa9480423e5a114e42aa262c2eaa954fa',1,'Users']]],
  ['getcurrentbiddername_72',['getCurrentBidderName',['../class_items.html#a7d917bc725d48662f4c7a1c4282500b8',1,'Items']]],
  ['getitemid_73',['getItemId',['../class_items.html#a0c388330de6695064785038ff35d3fd0',1,'Items']]],
  ['getitemname_74',['getItemName',['../class_items.html#a3d122c7849d2cc73021847331cd30df8',1,'Items']]],
  ['getpassword_75',['getPassword',['../class_users.html#ae7af722e9ae7acb285ad6e0926ada36e',1,'Users']]],
  ['getremainingdays_76',['getRemainingDays',['../class_advertise.html#ac7c9e8bbb6eb6d4d543cfa06176d6645',1,'Advertise']]],
  ['getsellername_77',['getSellerName',['../class_items.html#a1086ca155d8f4ba756a55a1bb5eca097',1,'Items']]],
  ['getusername_78',['getUserName',['../class_users.html#a1113a857236966f7c983ec94cd0c712d',1,'Users']]],
  ['getusertype_79',['getUserType',['../class_users.html#ac3633eb37bce94fbeefa8c62dc6435bf',1,'Users']]]
];
