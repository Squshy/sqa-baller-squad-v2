var searchData=
[
  ['deleteuser_66',['DeleteUser',['../class_admin.html#a027a095434a0373d22f4d45728511b19',1,'Admin']]],
  ['disableuser_67',['DisableUser',['../class_admin.html#a6f8d87913fd1c9954029ca7a67517b0d',1,'Admin']]]
];
