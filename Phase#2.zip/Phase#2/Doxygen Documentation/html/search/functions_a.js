var searchData=
[
  ['setbidprice_84',['setBidPrice',['../class_items.html#ac2dc3665562f22257a9c67f2830ecf81',1,'Items']]],
  ['setcredits_85',['setCredits',['../class_users.html#a94813e494d61c57e57fe638ab3f2ad73',1,'Users']]],
  ['setcurrentbiddername_86',['setCurrentBidderName',['../class_items.html#a56c474a5835bd1a7988c18c0c2843652',1,'Items']]],
  ['setitemid_87',['setItemId',['../class_items.html#a435af0bc94ed74edfe6f9d76d8be3fd6',1,'Items']]],
  ['setitemname_88',['setItemName',['../class_items.html#ac5998b5a4b80bbc90144493866cfe684',1,'Items']]],
  ['setpassword_89',['setPassword',['../class_users.html#ab9a3ee2f4947b8795b8eab1dcf71e9da',1,'Users']]],
  ['setremainingdays_90',['setRemainingDays',['../class_advertise.html#a62c14e0567b45fd9cf29ceaf5278d9ef',1,'Advertise']]],
  ['setsellername_91',['setSellerName',['../class_items.html#a591173895bd97e68f3e2164e9365c9b1',1,'Items']]],
  ['setusername_92',['setUserName',['../class_users.html#a9d723db6acea0f6f5f60030b8174fa5a',1,'Users']]],
  ['setusertype_93',['setUserType',['../class_users.html#ab7ce5adb58e3fe51d49e0df67d797450',1,'Users']]]
];
