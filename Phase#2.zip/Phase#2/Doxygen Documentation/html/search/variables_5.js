var searchData=
[
  ['session_5fcredit_5flimit_105',['SESSION_CREDIT_LIMIT',['../class_users.html#a33fefa1463f34d056023c3609203e60a',1,'Users']]]
];
