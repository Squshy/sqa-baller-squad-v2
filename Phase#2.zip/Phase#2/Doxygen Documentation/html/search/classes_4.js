var searchData=
[
  ['writer_55',['Writer',['../class_writer.html',1,'']]]
];
